<?php

namespace Plugin\NextdeskFilter;

use App\Services\Plugin\AbstractPlugin;

class Plugin extends AbstractPlugin
{
    private function debugLog(string $msg): void
    {
        $logFile = storage_path('logs/nextdesk_filter_debug.log');
        $ts = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[{$ts}] {$msg}\n", FILE_APPEND);
    }

    public function boot(): void
    {
        // Force Clash Meta format for NextDesk clients
        // This hook fires BEFORE protocol/format selection in ClientController
        $this->listen('client.subscribe.before', [$this, 'forceClashFormat']);

        // Filter rdp-only nodes for non-NextDesk clients
        $this->filter('client.subscribe.servers', [$this, 'filterProtectedNodes'], 25);
    }

    /**
     * Force XBoard to use Clash Meta format when NextDesk client is detected.
     * XBoard selects output format based on request 'flag' input or User-Agent.
     * Since NextDesk UA is not recognized, we inject 'flag=meta' into the request.
     */
    public function forceClashFormat(): void
    {
        try {
            $request = request();
            $userAgent = strtolower($request->header('User-Agent', ''));
            $clientIdentifier = strtolower((string) $this->getConfig('client_identifier', 'nextdesk'));

            if (empty($clientIdentifier)) {
                return;
            }

            if (str_contains($userAgent, $clientIdentifier)) {
                // Merge 'flag=meta' into request input so XBoard routes to ClashMeta protocol
                $request->merge(['flag' => 'meta']);
                $this->debugLog("Forced Clash Meta format for NextDesk client, UA={$userAgent}");
            }
        } catch (\Throwable $e) {
            // Fail-open: never break subscription delivery
            $this->debugLog("ERROR in forceClashFormat: {$e->getMessage()}");
        }
    }

    public function filterProtectedNodes(array $servers, $user, $request): array
    {
        try {
            $protectedTag = $this->getConfig('protected_tag', 'rdp-only');
            $clientIdentifier = strtolower((string) $this->getConfig('client_identifier', 'nextdesk'));

            // Skip filtering if not configured
            if (empty($protectedTag) || empty($clientIdentifier)) {
                return $servers;
            }

            // Detect if request comes from NextDesk client
            $userAgent = strtolower($request->header('User-Agent', ''));
            $flag = strtolower((string) $request->input('flag', ''));
            $isNextDesk = str_contains($userAgent, $clientIdentifier)
                || str_contains($flag, $clientIdentifier);

            if ($isNextDesk) {
                // NextDesk client: ONLY return servers with protected tag
                $filtered = array_values(array_filter($servers, function ($server) use ($protectedTag) {
                    $tags = $this->normalizeTags($server['tags'] ?? []);
                    return in_array($protectedTag, $tags, true);
                }));
                $count = count($filtered);
                $this->debugLog("NextDesk client detected, user={$user->id}, returning only {$count} rdp-only servers");
                return $filtered;
            }

            // Other clients: filter out servers with protected tag
            $filtered = array_values(array_filter($servers, function ($server) use ($protectedTag) {
                $tags = $this->normalizeTags($server['tags'] ?? []);
                return !in_array($protectedTag, $tags, true);
            }));

            $removed = count($servers) - count($filtered);
            if ($removed > 0) {
                $this->debugLog("Filtered {$removed} rdp-only nodes for non-NextDesk client, user={$user->id}");
            }

            return $filtered;
        } catch (\Throwable $e) {
            $this->debugLog("ERROR: {$e->getMessage()} at {$e->getFile()}:{$e->getLine()}");
            return $servers;
        }
    }

    private function normalizeTags($tags): array
    {
        if (is_string($tags)) {
            $decoded = json_decode($tags, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $this->normalizeTags($decoded);
            }
            return array_values(array_filter(array_map('trim', explode(',', $tags)), 'strlen'));
        }

        if (!is_array($tags)) {
            return [];
        }

        $normalized = [];
        foreach ($tags as $tag) {
            if (is_string($tag) || is_numeric($tag)) {
                $normalized[] = trim((string) $tag);
                continue;
            }
            if (is_array($tag)) {
                foreach (['name', 'tag', 'label', 'value'] as $key) {
                    if (isset($tag[$key]) && (is_string($tag[$key]) || is_numeric($tag[$key]))) {
                        $normalized[] = trim((string) $tag[$key]);
                        break;
                    }
                }
            }
        }

        return array_values(array_unique(array_filter($normalized, 'strlen')));
    }
}
